#pragma once

class Challenge {
private:
	char _input[37] = "0 37551 469 63 1 791606 2065 9983586";

public:
	long Run(char cycles);

};