#include"Challenge.h"

long Challenge::Run(char cycles) {
	return 0;
}